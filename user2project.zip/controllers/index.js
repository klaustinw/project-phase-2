const StudentController = require('./student');
const ProjectController = require('./project');
const StudentProjectController = require('./studentproject');
const session = require('express-session');

class HomeController {
    static main(req, res) {
        res.render('home');
    }

    static login(req, res) {
        res.render('login');
    }
}

module.exports = {HomeController, StudentController, ProjectController, StudentProjectController};